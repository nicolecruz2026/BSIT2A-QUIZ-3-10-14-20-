﻿Public Class RhymattSpecialPizza

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = Today.ToString
        Label2.Text = TimeOfDay
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim Inp As String
        If RadioButton1.Checked Then
            Inp = Inp + RadioButton1.Text + vbNewLine
        End If
        If RadioButton2.Checked Then
            Inp = Inp + RadioButton2.Text + vbNewLine
        End If
        If RadioButton3.Checked Then
            Inp = Inp + RadioButton3.Text + vbNewLine
        End If
        If RadioButton4.Checked Then
            Inp = Inp + RadioButton4.Text + vbNewLine
        End If
        If RadioButton5.Checked Then
            Inp = Inp + RadioButton5.Text + vbNewLine
        End If
        If RadioButton6.Checked Then
            Inp = Inp + RadioButton6.Text + vbNewLine
        End If
        If RadioButton7.Checked Then
            Inp = Inp + RadioButton7.Text + vbNewLine
        End If
        If RadioButton8.Checked Then
            Inp = Inp + RadioButton8.Text + vbNewLine
        End If
        If RadioButton9.Checked Then
            Inp = Inp + RadioButton9.Text + vbNewLine
        End If
        If RadioButton10.Checked Then
            Inp = Inp + RadioButton10.Text + vbNewLine
        End If
        If CheckBox1.Checked Then
            Inp = Inp + CheckBox1.Text + vbNewLine
        End If
        If CheckBox2.Checked Then
            Inp = Inp + CheckBox2.Text + vbNewLine
        End If
        If CheckBox3.Checked Then
            Inp = Inp + CheckBox3.Text + vbNewLine
        End If
        If CheckBox4.Checked Then
            Inp = Inp + CheckBox4.Text + vbNewLine
        End If
        If CheckBox5.Checked Then
            Inp = Inp + CheckBox5.Text + vbNewLine
        End If
        If CheckBox6.Checked Then
            Inp = Inp + CheckBox6.Text + vbNewLine
        End If
        MessageBox.Show("Your Pizza: " + vbNewLine + Inp, "Your Pizza")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        CheckBox3.Checked = False
        CheckBox4.Checked = False
        CheckBox5.Checked = False
        CheckBox6.Checked = False
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim Total, Pizza, ExtraToppings, Drinks As Double
        Dim Small As Double = 100.0
        Dim Medium As Double = 150.0
        Dim Large As Double = 200.0
        Dim Thick As Double = 0.5
        Dim Softdrinks As Double = 20.0
        Dim FruitJuice As Double = 15.0
        Dim CoffeeChocolate As Double = 25.0
        Dim ExtraCheese As Double = 10.0
        Dim Mushrooms As Double = 10.0
        Dim BlackOlives As Double = 10.0
        Dim Onions As Double = 10.0
        Dim GreenPeppers As Double = 10.0
        Dim Tomatoes As Double = 10.0

        If RadioButton1.Checked = True Then
            Pizza = Small
            If RadioButton5.Checked = True Then
                Pizza = Small * Thick
            End If
            TextBox1.Text = Pizza
        ElseIf RadioButton2.Checked = True Then
            Pizza = Medium
            If RadioButton5.Checked = True Then
                Pizza = Medium * Thick
            End If
            TextBox1.Text = Pizza
        ElseIf RadioButton3.Checked Then
            Pizza = Large
            If RadioButton5.Checked = True Then
                Pizza = Large * Thick
            End If
            TextBox1.Text = Pizza

        End If

        If CheckBox1.Checked = True Then
            ExtraToppings += 10
        End If
        If CheckBox2.Checked = True Then
            ExtraToppings += 10
        End If
        If CheckBox3.Checked = True Then
            ExtraToppings += 10
        End If
        If CheckBox4.Checked = True Then
            ExtraToppings += 10
        End If
        If CheckBox5.Checked = True Then
            ExtraToppings += 10
        End If
        If CheckBox6.Checked = True Then
            ExtraToppings += 10
        End If
        TextBox2.Text = ExtraToppings

        If RadioButton6.Checked = True Then
            Drinks = Softdrinks
            TextBox3.Text = Drinks
        ElseIf RadioButton7.Checked = True Then
            Drinks = FruitJuice
            TextBox3.Text = Drinks
        ElseIf RadioButton8.Checked = True Then
            Drinks = CoffeeChocolate
            TextBox3.Text = Drinks
        End If

        Total = Pizza + ExtraToppings + Drinks
        TextBox4.Text = Total

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
        RadioButton4.Checked = False
        RadioButton5.Checked = False
        RadioButton6.Checked = False
        RadioButton7.Checked = False
        RadioButton8.Checked = False
        RadioButton9.Checked = False
        RadioButton10.Checked = False
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        CheckBox3.Checked = False
        CheckBox4.Checked = False
        CheckBox5.Checked = False
        CheckBox6.Checked = False
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Close()
    End Sub
End Class