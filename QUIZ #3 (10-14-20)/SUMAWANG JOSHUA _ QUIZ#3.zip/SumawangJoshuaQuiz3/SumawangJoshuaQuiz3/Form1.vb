﻿Public Class MPFRM01JoshuaSumawang
    Dim ratepay, Basicpay, SSS, sssrate, withholding, netpay As Double
    Dim Employee As Char

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        ratepay = 0.5
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Employee = LCase(ComboBox2.Text)
        Select Case Employee

            Case "a"
                Basicpay = DomainUpDown1.Text * 500
                If Basicpay >= 10000 Then
                    sssrate = 0.07
                ElseIf Basicpay >= 5000 Then
                    sssrate = 0.05
                ElseIf Basicpay >= 1000 Then
                    sssrate = 0.03
                ElseIf Basicpay < 1000 Then
                    sssrate = 0.01

                End If
                SSS = Basicpay * sssrate
                withholding = Basicpay * ratepay
                netpay = Basicpay - (SSS + withholding)
                TextBox5.Text = Basicpay
                TextBox6.Text = SSS
                TextBox7.Text = withholding
                TextBox8.Text = netpay

            Case "b"
                basicpay = DomainUpDown1.Text * 400
                If Basicpay >= 10000 Then
                    sssrate = 0.07
                ElseIf Basicpay >= 5000 Then
                    sssrate = 0.05
                ElseIf Basicpay >= 1000 Then
                    sssrate = 0.03
                ElseIf Basicpay < 1000 Then
                    sssrate = 0.01

                End If
                SSS = Basicpay * sssrate
                withholding = basicpay * ratepay
                netpay = Basicpay - (SSS + withholding)
                TextBox5.Text = basicpay
                TextBox6.Text = SSS
                TextBox7.Text = withholding
                TextBox8.Text = netpay
            Case "c"
                basicpay = DomainUpDown1.Text * 300
                If basicpay >= 10000 Then
                    sssrate = 0.07
                ElseIf basicpay >= 5000 Then
                    sssrate = 0.05
                ElseIf basicpay >= 1000 Then
                    sssrate = 0.03
                ElseIf basicpay < 1000 Then
                    sssrate = 0.01

                End If
                SSS = Basicpay * sssrate
                withholding = Basicpay * ratepay
                netpay = Basicpay - (sss + withholding)
                TextBox5.Text = Basicpay
                TextBox6.Text = SSS
                TextBox7.Text = withholding
                TextBox8.Text = netpay
        End Select






    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        ratepay = 0.1
    End Sub

    Private Sub RadioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        ratepay = 0.5
    End Sub


    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub

    
 
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox2.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()
    End Sub
End Class
