﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM02JohnLawrenceMarasigan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdolrg = New System.Windows.Forms.RadioButton()
        Me.rdomed = New System.Windows.Forms.RadioButton()
        Me.rdosmall = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rdothck = New System.Windows.Forms.RadioButton()
        Me.rdothn = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rdocc = New System.Windows.Forms.RadioButton()
        Me.rdofj = New System.Windows.Forms.RadioButton()
        Me.rdosd = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.rdodine = New System.Windows.Forms.RadioButton()
        Me.rdotake = New System.Windows.Forms.RadioButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(439, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Label2"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdolrg)
        Me.GroupBox1.Controls.Add(Me.rdomed)
        Me.GroupBox1.Controls.Add(Me.rdosmall)
        Me.GroupBox1.Location = New System.Drawing.Point(30, 56)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(155, 116)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Size"
        '
        'rdolrg
        '
        Me.rdolrg.AutoSize = True
        Me.rdolrg.Location = New System.Drawing.Point(27, 81)
        Me.rdolrg.Name = "rdolrg"
        Me.rdolrg.Size = New System.Drawing.Size(52, 17)
        Me.rdolrg.TabIndex = 2
        Me.rdolrg.TabStop = True
        Me.rdolrg.Text = "Large"
        Me.rdolrg.UseVisualStyleBackColor = True
        '
        'rdomed
        '
        Me.rdomed.AutoSize = True
        Me.rdomed.Location = New System.Drawing.Point(27, 50)
        Me.rdomed.Name = "rdomed"
        Me.rdomed.Size = New System.Drawing.Size(62, 17)
        Me.rdomed.TabIndex = 1
        Me.rdomed.TabStop = True
        Me.rdomed.Text = "Medium"
        Me.rdomed.UseVisualStyleBackColor = True
        '
        'rdosmall
        '
        Me.rdosmall.AutoSize = True
        Me.rdosmall.Location = New System.Drawing.Point(27, 19)
        Me.rdosmall.Name = "rdosmall"
        Me.rdosmall.Size = New System.Drawing.Size(50, 17)
        Me.rdosmall.TabIndex = 0
        Me.rdosmall.TabStop = True
        Me.rdosmall.Text = "Small"
        Me.rdosmall.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rdothck)
        Me.GroupBox2.Controls.Add(Me.rdothn)
        Me.GroupBox2.Location = New System.Drawing.Point(30, 178)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(154, 75)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Crust Type"
        '
        'rdothck
        '
        Me.rdothck.AutoSize = True
        Me.rdothck.Location = New System.Drawing.Point(27, 42)
        Me.rdothck.Name = "rdothck"
        Me.rdothck.Size = New System.Drawing.Size(79, 17)
        Me.rdothck.TabIndex = 1
        Me.rdothck.TabStop = True
        Me.rdothck.Text = "Thick Crust"
        Me.rdothck.UseVisualStyleBackColor = True
        '
        'rdothn
        '
        Me.rdothn.AutoSize = True
        Me.rdothn.Location = New System.Drawing.Point(27, 19)
        Me.rdothn.Name = "rdothn"
        Me.rdothn.Size = New System.Drawing.Size(73, 17)
        Me.rdothn.TabIndex = 0
        Me.rdothn.TabStop = True
        Me.rdothn.Text = "Thin Crust"
        Me.rdothn.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rdocc)
        Me.GroupBox3.Controls.Add(Me.rdofj)
        Me.GroupBox3.Controls.Add(Me.rdosd)
        Me.GroupBox3.Location = New System.Drawing.Point(30, 259)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(154, 96)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Drinks"
        '
        'rdocc
        '
        Me.rdocc.AutoSize = True
        Me.rdocc.Location = New System.Drawing.Point(27, 65)
        Me.rdocc.Name = "rdocc"
        Me.rdocc.Size = New System.Drawing.Size(109, 17)
        Me.rdocc.TabIndex = 2
        Me.rdocc.TabStop = True
        Me.rdocc.Text = "Coffee/Chocolate"
        Me.rdocc.UseVisualStyleBackColor = True
        '
        'rdofj
        '
        Me.rdofj.AutoSize = True
        Me.rdofj.Location = New System.Drawing.Point(27, 42)
        Me.rdofj.Name = "rdofj"
        Me.rdofj.Size = New System.Drawing.Size(73, 17)
        Me.rdofj.TabIndex = 1
        Me.rdofj.TabStop = True
        Me.rdofj.Text = "Fruit Juice"
        Me.rdofj.UseVisualStyleBackColor = True
        '
        'rdosd
        '
        Me.rdosd.AutoSize = True
        Me.rdosd.Location = New System.Drawing.Point(27, 19)
        Me.rdosd.Name = "rdosd"
        Me.rdosd.Size = New System.Drawing.Size(77, 17)
        Me.rdosd.TabIndex = 0
        Me.rdosd.TabStop = True
        Me.rdosd.Text = "Soft Drinks"
        Me.rdosd.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.CheckBox6)
        Me.GroupBox4.Controls.Add(Me.CheckBox5)
        Me.GroupBox4.Controls.Add(Me.CheckBox4)
        Me.GroupBox4.Controls.Add(Me.CheckBox3)
        Me.GroupBox4.Controls.Add(Me.CheckBox2)
        Me.GroupBox4.Controls.Add(Me.CheckBox1)
        Me.GroupBox4.Location = New System.Drawing.Point(210, 56)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(303, 136)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Extra Toppings"
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(157, 99)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(73, 17)
        Me.CheckBox6.TabIndex = 5
        Me.CheckBox6.Text = "Tomatoes"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(157, 64)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(97, 17)
        Me.CheckBox5.TabIndex = 4
        Me.CheckBox5.Text = "Green Peppers"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(157, 30)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(59, 17)
        Me.CheckBox4.TabIndex = 3
        Me.CheckBox4.Text = "Onions"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(30, 99)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(85, 17)
        Me.CheckBox3.TabIndex = 2
        Me.CheckBox3.Text = "Black Olives"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(30, 64)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(80, 17)
        Me.CheckBox2.TabIndex = 1
        Me.CheckBox2.Text = "Mushrooms"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(30, 30)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(89, 17)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Extra Cheese"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.TextBox4)
        Me.GroupBox5.Controls.Add(Me.TextBox3)
        Me.GroupBox5.Controls.Add(Me.TextBox2)
        Me.GroupBox5.Controls.Add(Me.TextBox1)
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Location = New System.Drawing.Point(210, 229)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(216, 176)
        Me.GroupBox5.TabIndex = 6
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Amount"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(110, 142)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 7
        Me.TextBox4.Text = "0.00"
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(110, 91)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 6
        Me.TextBox3.Text = "0.00"
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(110, 59)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 5
        Me.TextBox2.Text = "0.00"
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(110, 27)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 4
        Me.TextBox1.Text = "0.00"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 142)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "TOTAL:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(27, 94)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Drinks:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(27, 62)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Extra Toppings:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 30)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Pizza:"
        '
        'rdodine
        '
        Me.rdodine.AutoSize = True
        Me.rdodine.Location = New System.Drawing.Point(30, 369)
        Me.rdodine.Name = "rdodine"
        Me.rdodine.Size = New System.Drawing.Size(59, 17)
        Me.rdodine.TabIndex = 7
        Me.rdodine.TabStop = True
        Me.rdodine.Text = "Dine-In"
        Me.rdodine.UseVisualStyleBackColor = True
        '
        'rdotake
        '
        Me.rdotake.AutoSize = True
        Me.rdotake.Location = New System.Drawing.Point(115, 369)
        Me.rdotake.Name = "rdotake"
        Me.rdotake.Size = New System.Drawing.Size(70, 17)
        Me.rdotake.TabIndex = 8
        Me.rdotake.TabStop = True
        Me.rdotake.Text = "Take-Out"
        Me.rdotake.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(210, 198)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(145, 25)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "Build Pizza"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(368, 198)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(145, 25)
        Me.Button2.TabIndex = 10
        Me.Button2.Text = "Clear Toppings"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(442, 229)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(71, 49)
        Me.Button3.TabIndex = 11
        Me.Button3.Text = "COMPUTE"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(442, 292)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(71, 49)
        Me.Button4.TabIndex = 12
        Me.Button4.Text = "Clear All"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(442, 355)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(71, 49)
        Me.Button5.TabIndex = 13
        Me.Button5.Text = "Exit"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'MPFRM02JohnLawrenceMarasigan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(543, 440)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.rdotake)
        Me.Controls.Add(Me.rdodine)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "MPFRM02JohnLawrenceMarasigan"
        Me.Text = "MARASIGAN Special Pizza"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdolrg As System.Windows.Forms.RadioButton
    Friend WithEvents rdomed As System.Windows.Forms.RadioButton
    Friend WithEvents rdosmall As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rdothck As System.Windows.Forms.RadioButton
    Friend WithEvents rdothn As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rdocc As System.Windows.Forms.RadioButton
    Friend WithEvents rdofj As System.Windows.Forms.RadioButton
    Friend WithEvents rdosd As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents rdodine As System.Windows.Forms.RadioButton
    Friend WithEvents rdotake As System.Windows.Forms.RadioButton
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
