﻿Public Class MPFRM01JohnLawrenceMarasigan


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        rdoSingle.Checked = False
        rdoMarried.Checked = False
        rdoWidowed.Checked = False
        DomainUpDown1.Text = ""


    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim positioncode As Char
        Dim basicpay, rpd, dow, ssscontribution, withholdingtax, netpay As Double
        positioncode = ComboBox2.SelectedItem
        If positioncode = "A" Then
            rpd = 500
            dow = DomainUpDown1.SelectedItem
            basicpay = rpd * dow
            TextBox2.Text = Format(basicpay, "#,###.00")
            If basicpay >= 10000 Then
                ssscontribution = basicpay * 0.07
                TextBox3.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay <= 9999 And basicpay >= 5000 Then
                ssscontribution = basicpay * 0.05
                TextBox3.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay <= 4999 Or basicpay >= 1000 Then
                ssscontribution = basicpay * 0.03
                TextBox3.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay < 1000 Then
                ssscontribution = basicpay * 0.01
                TextBox3.Text = Format(ssscontribution, "#,###.00")
            End If
            If rdoSingle.Checked = True Then withholdingtax = basicpay * 0.1
            TextBox4.Text = Format(withholdingtax, "#,###.00")
        ElseIf rdoMarried.Checked = True Then
            withholdingtax = basicpay * 0.05
            TextBox4.Text = Format(withholdingtax, "#,###.00")
        ElseIf rdoWidowed.Checked = True Then
            withholdingtax = basicpay * 0.05
            TextBox4.Text = Format(withholdingtax, "#,###.00")
        End If
        netpay = basicpay - (ssscontribution + withholdingtax)
        TextBox5.Text = Format(netpay, "###,###.00")

        If positioncode = "B" Then
            rpd = 400
            dow = DomainUpDown1.SelectedItem
            basicpay = rpd * dow
            TextBox2.Text = Format(basicpay, "#,###.00")
            If basicpay >= 10000 Then ssscontribution = basicpay * 0.07
            TextBox3.Text = Format(ssscontribution, "#,###.00")
        ElseIf basicpay <= 9999 And basicpay >= 5000 Then
            ssscontribution = basicpay * 0.05
            TextBox3.Text = Format(ssscontribution, "#,###.00")
        ElseIf basicpay <= 4999 Or basicpay >= 1000 Then
            ssscontribution = basicpay * 0.03
            TextBox3.Text = Format(ssscontribution, "#,###.00")
        ElseIf basicpay < 1000 Then
            ssscontribution = basicpay * 0.01
            TextBox3.Text = Format(ssscontribution, "#,###.00")
        End If
        If rdoSingle.Checked = True Then
            withholdingtax = basicpay * 0.1
            TextBox4.Text = Format(withholdingtax, "#,###.00")
        ElseIf rdoMarried.Checked = True Then
            withholdingtax = basicpay * 0.05
            TextBox4.Text = Format(withholdingtax, "#,###.00")
        ElseIf rdoWidowed.Checked = True Then
            withholdingtax = basicpay * 0.05
            TextBox4.Text = Format(withholdingtax, "#,###.00")
        End If
        netpay = basicpay - (ssscontribution + withholdingtax)
        TextBox5.Text = Format(netpay, "###,###.00")



        If positioncode = "C" Then
            rpd = 300
            dow = DomainUpDown1.SelectedItem
            basicpay = rpd * dow
            TextBox2.Text = Format(basicpay, "#,###.00")
            If basicpay >= 10000 Then ssscontribution = basicpay * 0.07
            TextBox3.Text = Format(ssscontribution, "#,###.00")
        ElseIf basicpay <= 9999 And basicpay >= 5000 Then
            ssscontribution = basicpay * 0.05
            TextBox3.Text = Format(ssscontribution, "#,###.00")
        ElseIf basicpay <= 4999 Or basicpay >= 1000 Then
            ssscontribution = basicpay * 0.03
            TextBox3.Text = Format(ssscontribution, "#,###.00")
        ElseIf basicpay < 1000 Then
            ssscontribution = basicpay * 0.01
            TextBox3.Text = Format(ssscontribution, "#,###.00")
        End If
        If rdoSingle.Checked = True Then
            withholdingtax = basicpay * 0.1
            TextBox4.Text = Format(withholdingtax, "#,###.00")
        ElseIf rdoMarried.Checked = True Then
            withholdingtax = basicpay * 0.05
            TextBox4.Text = Format(withholdingtax, "#,###.00")
        ElseIf rdoWidowed.Checked = True Then
            withholdingtax = basicpay * 0.05
            TextBox4.Text = Format(withholdingtax, "#,###.00")
        End If
        netpay = basicpay - (ssscontribution + withholdingtax)
        TextBox5.Text = Format(netpay, "###,###.00")





    End Sub

    


    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedItem = 1 Then
            TextBox1.Text = "JOHN LAWRENCE MARASIGAN"
        ElseIf ComboBox1.SelectedItem = 2 Then
            TextBox1.Text = " AIRA REYES"
        ElseIf ComboBox1.SelectedItem = 3 Then
            TextBox1.Text = "KYLE CHANLIONGCO"

        End If
    End Sub


End Class