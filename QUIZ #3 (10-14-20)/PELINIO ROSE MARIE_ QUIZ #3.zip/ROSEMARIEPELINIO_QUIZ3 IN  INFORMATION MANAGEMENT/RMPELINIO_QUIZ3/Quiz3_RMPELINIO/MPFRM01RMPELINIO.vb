﻿Public Class MPFRM01RMPELINIO


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox2.Text = ""
        TextBox5.Text = ""
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
        DomainUpDown1.Text = ""    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim positioncode As Char
        Dim basicpay, ssscontribution, withholdingtax, netpay As Double
        positioncode = ComboBox2.SelectedItem
        If positioncode = "A" Then
            basicpay = DomainUpDown1.SelectedItem * 500
            TextBox5.Text = Format(basicpay, "#,###.00")
            If basicpay >= 10000 Then
                ssscontribution = basicpay * 0.07
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay <= 9999 And basicpay >= 5000 Then
                ssscontribution = basicpay * 0.05
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay <= 4999 Or basicpay >= 1000 Then
                ssscontribution = basicpay * 0.03
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay < 1000 Then
                ssscontribution = basicpay * 0.01
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            End If
            If RadioButton1.Checked = True Then
                withholdingtax = basicpay * 0.1
                TextBox7.Text = Format(withholdingtax, "#,###.00")
            ElseIf RadioButton2.Checked = True Then
                withholdingtax = basicpay * 0.05
                TextBox7.Text = Format(withholdingtax, "#,###.00")
            ElseIf RadioButton3.Checked = True Then
                withholdingtax = basicpay * 0.05
                TextBox7.Text = Format(withholdingtax, "#,###.00")
            End If
            netpay = basicpay - (ssscontribution + withholdingtax)
            TextBox8.Text = netpay
        End If
        If positioncode = "B" Then
            basicpay = DomainUpDown1.SelectedItem * 400
            TextBox5.Text = Format(basicpay, "#,###.00")
            If basicpay >= 10000 Then
                ssscontribution = basicpay * 0.07
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay <= 9999 And basicpay >= 5000 Then
                ssscontribution = basicpay * 0.05
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay <= 4999 Or basicpay >= 1000 Then
                ssscontribution = basicpay * 0.03
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay < 1000 Then
                ssscontribution = basicpay * 0.01
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            End If
            If RadioButton1.Checked = True Then
                withholdingtax = basicpay * 0.1
                TextBox7.Text = Format(withholdingtax, "#,###.00")
            ElseIf RadioButton2.Checked = True Then
                withholdingtax = basicpay * 0.05
                TextBox7.Text = Format(withholdingtax, "#,###.00")
            ElseIf RadioButton3.Checked = True Then
                withholdingtax = basicpay * 0.05
                TextBox7.Text = Format(withholdingtax, "#,###.00")
            End If
            netpay = basicpay - (ssscontribution + withholdingtax)
            TextBox8.Text = netpay
        End If        If positioncode = "C" Then
            basicpay = DomainUpDown1.SelectedItem * 300
            TextBox5.Text = Format(basicpay, "#,###.00")
            If basicpay >= 10000 Then
                ssscontribution = basicpay * 0.07
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay <= 9999 And basicpay >= 5000 Then
                ssscontribution = basicpay * 0.05
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay <= 4999 Or basicpay >= 1000 Then
                ssscontribution = basicpay * 0.03
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            ElseIf basicpay < 1000 Then
                ssscontribution = basicpay * 0.01
                TextBox6.Text = Format(ssscontribution, "#,###.00")
            End If
            If RadioButton1.Checked = True Then
                withholdingtax = basicpay * 0.1
                TextBox7.Text = Format(withholdingtax, "#,###.00")
            ElseIf RadioButton2.Checked = True Then
                withholdingtax = basicpay * 0.05
                TextBox7.Text = Format(withholdingtax, "#,###.00")
            ElseIf RadioButton3.Checked = True Then
                withholdingtax = basicpay * 0.05
                TextBox7.Text = Format(withholdingtax, "#,###.00")
            End If            netpay = basicpay - (ssscontribution + withholdingtax)
            TextBox5.Text = netpay
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedItem = 1 Then
            TextBox2.Text = "Rose Marie Pelinio"
        ElseIf ComboBox1.SelectedItem = 2 Then
            TextBox2.Text = "Cathyrene German"
        ElseIf ComboBox1.SelectedItem = 3 Then
            TextBox2.Text = "Pauline Tumala"
        End If
    End Sub
End Class
