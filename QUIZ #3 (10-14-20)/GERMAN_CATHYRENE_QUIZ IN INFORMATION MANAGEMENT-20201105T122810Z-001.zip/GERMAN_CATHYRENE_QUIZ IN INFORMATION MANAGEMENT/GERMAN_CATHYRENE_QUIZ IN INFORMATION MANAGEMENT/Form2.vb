﻿Public Class MPFRM02Cathyrene
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim subject As String
        subject = ""
        If RadioButton11.Checked = True Then
            subject = subject + RadioButton11.Text + vbNewLine
        End If
        If RadioButton12.Checked = True Then
            subject = subject + RadioButton12.Text + vbNewLine
        End If
        If RadioButton13.Checked = True Then
            subject = subject + RadioButton13.Text + vbNewLine
        End If
        If RadioButton14.Checked = True Then
            subject = subject + RadioButton14.Text + vbNewLine
        End If
        If RadioButton15.Checked = True Then
            subject = subject + RadioButton15.Text + vbNewLine
        End If
        If RadioButton16.Checked = True Then
            subject = subject + RadioButton16.Text + vbNewLine
        End If
        If RadioButton17.Checked = True Then
            subject = subject + RadioButton17.Text + vbNewLine
        End If
        If RadioButton18.Checked = True Then
            subject = subject + RadioButton18.Text + vbNewLine
        End If
        If RadioButton19.Checked = True Then
            subject = subject + RadioButton19.Text + vbNewLine
        End If
        If RadioButton20.Checked = True Then
            subject = subject + RadioButton20.Text + vbNewLine
        End If
        If CheckBox7.Checked Then
            subject = subject + CheckBox7.Text + vbNewLine
        End If
        If CheckBox8.Checked Then
            subject = subject + CheckBox8.Text + vbNewLine
        End If
        If CheckBox9.Checked Then
            subject = subject + CheckBox9.Text + vbNewLine
        End If
        If CheckBox10.Checked Then
            subject = subject + CheckBox10.Text + vbNewLine
        End If
        If CheckBox11.Checked Then
            subject = subject + CheckBox11.Text + vbNewLine
        End If
        If CheckBox12.Checked Then
            subject = subject + CheckBox12.Text + vbNewLine
        End If
        MessageBox.Show(subject, "Your Pizza")
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        CheckBox7.Checked = False
        CheckBox8.Checked = False
        CheckBox9.Checked = False
        CheckBox10.Checked = False
        CheckBox11.Checked = False
        CheckBox12.Checked = False
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim size, type, drinks, total As Double
        Dim sum As Double
        Const extra1 As Double = 10
        Const extra2 As Double = 10
        Const extra3 As Double = 10
        Const extra4 As Double = 10
        Const extra5 As Double = 10
        Const extra6 As Double = 10

        If RadioButton11.Checked = True Then
            size = 100
        ElseIf RadioButton12.Checked = True Then
            size = 150
        ElseIf RadioButton13.Checked = True Then
            size = 200
        End If
        If RadioButton14.Checked = True Then
            type = 0
        ElseIf RadioButton15.Checked = True Then
            type = size * 0.5
        End If
        size = size + type
        TextBox5.Text = Format(size, "###,###.00")
        If CheckBox7.Checked = True Then
            sum = sum + extra1
        End If
        If CheckBox8.Checked = True Then
            sum = sum + extra2
        End If
        If CheckBox9.Checked = True Then
            sum = sum + extra3
        End If
        If CheckBox10.Checked = True Then
            sum = sum + extra4
        End If
        If CheckBox11.Checked = True Then
            sum = sum + extra5
        End If
        If CheckBox12.Checked = True Then
            sum = sum + extra6
        End If
        TextBox6.Text = sum.ToString & ".00"
        If RadioButton13.Checked = True Then
            drinks = 20
        ElseIf RadioButton14.Checked = True Then
            drinks = 15
        ElseIf RadioButton15.Checked = True Then
            drinks = 25
        End If
        TextBox6.Text = Format(drinks, "###,###.00")
        total = size + sum + drinks
        TextBox8.Text = Format(total, "###,###.00")
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        RadioButton11.Checked = False
        RadioButton12.Checked = False
        RadioButton13.Checked = False
        RadioButton14.Checked = False
        RadioButton15.Checked = False
        RadioButton16.Checked = False
        RadioButton17.Checked = False
        RadioButton18.Checked = False
        RadioButton19.Checked = False
        RadioButton20.Checked = False
        CheckBox7.Checked = False
        CheckBox8.Checked = False
        CheckBox9.Checked = False
        CheckBox10.Checked = False
        CheckBox11.Checked = False
        CheckBox12.Checked = False
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        Close()
    End Sub

End Class
