﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM01EmmanuelleElimanco
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdWidowed = New System.Windows.Forms.RadioButton()
        Me.rdMarried = New System.Windows.Forms.RadioButton()
        Me.rdSingle = New System.Windows.Forms.RadioButton()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbPosition = New System.Windows.Forms.ComboBox()
        Me.cb1 = New System.Windows.Forms.ComboBox()
        Me.txtEmployee = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtNet = New System.Windows.Forms.TextBox()
        Me.txtWith = New System.Windows.Forms.TextBox()
        Me.txtSss = New System.Windows.Forms.TextBox()
        Me.txtBasic = New System.Windows.Forms.TextBox()
        Me.nudNo = New System.Windows.Forms.NumericUpDown()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.nudNo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdWidowed)
        Me.GroupBox1.Controls.Add(Me.rdMarried)
        Me.GroupBox1.Controls.Add(Me.rdSingle)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.cbPosition)
        Me.GroupBox1.Controls.Add(Me.cb1)
        Me.GroupBox1.Controls.Add(Me.txtEmployee)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 71)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(326, 292)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Enter Date Record Here:"
        '
        'rdWidowed
        '
        Me.rdWidowed.AutoSize = True
        Me.rdWidowed.Location = New System.Drawing.Point(215, 244)
        Me.rdWidowed.Name = "rdWidowed"
        Me.rdWidowed.Size = New System.Drawing.Size(86, 21)
        Me.rdWidowed.TabIndex = 9
        Me.rdWidowed.TabStop = True
        Me.rdWidowed.Text = "Widowed"
        Me.rdWidowed.UseVisualStyleBackColor = True
        '
        'rdMarried
        '
        Me.rdMarried.AutoSize = True
        Me.rdMarried.Location = New System.Drawing.Point(110, 244)
        Me.rdMarried.Name = "rdMarried"
        Me.rdMarried.Size = New System.Drawing.Size(77, 21)
        Me.rdMarried.TabIndex = 8
        Me.rdMarried.TabStop = True
        Me.rdMarried.Text = "Married"
        Me.rdMarried.UseVisualStyleBackColor = True
        '
        'rdSingle
        '
        Me.rdSingle.AutoSize = True
        Me.rdSingle.Location = New System.Drawing.Point(15, 244)
        Me.rdSingle.Name = "rdSingle"
        Me.rdSingle.Size = New System.Drawing.Size(68, 21)
        Me.rdSingle.TabIndex = 7
        Me.rdSingle.TabStop = True
        Me.rdSingle.Text = "Single"
        Me.rdSingle.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 186)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(77, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Civil Status"
        '
        'cbPosition
        '
        Me.cbPosition.Enabled = False
        Me.cbPosition.FormattingEnabled = True
        Me.cbPosition.Location = New System.Drawing.Point(162, 130)
        Me.cbPosition.Name = "cbPosition"
        Me.cbPosition.Size = New System.Drawing.Size(139, 24)
        Me.cbPosition.TabIndex = 5
        '
        'cb1
        '
        Me.cb1.FormattingEnabled = True
        Me.cb1.Items.AddRange(New Object() {"EN0001", "EN0002", "EN0003"})
        Me.cb1.Location = New System.Drawing.Point(162, 36)
        Me.cb1.Name = "cb1"
        Me.cb1.Size = New System.Drawing.Size(139, 24)
        Me.cb1.TabIndex = 4
        '
        'txtEmployee
        '
        Me.txtEmployee.Location = New System.Drawing.Point(162, 82)
        Me.txtEmployee.Name = "txtEmployee"
        Me.txtEmployee.Size = New System.Drawing.Size(139, 22)
        Me.txtEmployee.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 130)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Position Code"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(111, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Employee Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(124, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Employee Number"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtNet)
        Me.GroupBox2.Controls.Add(Me.txtWith)
        Me.GroupBox2.Controls.Add(Me.txtSss)
        Me.GroupBox2.Controls.Add(Me.txtBasic)
        Me.GroupBox2.Controls.Add(Me.nudNo)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(366, 71)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(326, 292)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Computations:"
        '
        'txtNet
        '
        Me.txtNet.Location = New System.Drawing.Point(171, 231)
        Me.txtNet.Name = "txtNet"
        Me.txtNet.Size = New System.Drawing.Size(139, 22)
        Me.txtNet.TabIndex = 9
        '
        'txtWith
        '
        Me.txtWith.Location = New System.Drawing.Point(171, 183)
        Me.txtWith.Name = "txtWith"
        Me.txtWith.Size = New System.Drawing.Size(139, 22)
        Me.txtWith.TabIndex = 8
        '
        'txtSss
        '
        Me.txtSss.Location = New System.Drawing.Point(171, 132)
        Me.txtSss.Name = "txtSss"
        Me.txtSss.Size = New System.Drawing.Size(139, 22)
        Me.txtSss.TabIndex = 7
        '
        'txtBasic
        '
        Me.txtBasic.Location = New System.Drawing.Point(171, 82)
        Me.txtBasic.Name = "txtBasic"
        Me.txtBasic.Size = New System.Drawing.Size(139, 22)
        Me.txtBasic.TabIndex = 6
        '
        'nudNo
        '
        Me.nudNo.Location = New System.Drawing.Point(171, 37)
        Me.nudNo.Name = "nudNo"
        Me.nudNo.Size = New System.Drawing.Size(139, 22)
        Me.nudNo.TabIndex = 5
        Me.nudNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(12, 231)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(58, 17)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Net Pay"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 186)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 17)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Witholding Tax"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 130)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(115, 17)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "SSS Contribution"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 82)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(70, 17)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Basic Pay"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(135, 17)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "No. of Days Worked"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.btnQuit)
        Me.Panel1.Controls.Add(Me.btnCompute)
        Me.Panel1.Controls.Add(Me.btnClear)
        Me.Panel1.Location = New System.Drawing.Point(12, 383)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(679, 57)
        Me.Panel1.TabIndex = 2
        '
        'btnQuit
        '
        Me.btnQuit.Location = New System.Drawing.Point(504, 11)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(158, 30)
        Me.btnQuit.TabIndex = 2
        Me.btnQuit.Text = "QUIT"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnCompute
        '
        Me.btnCompute.Location = New System.Drawing.Point(264, 11)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(158, 30)
        Me.btnCompute.TabIndex = 1
        Me.btnCompute.Text = "COMPUTE"
        Me.btnCompute.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(13, 11)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(158, 30)
        Me.btnClear.TabIndex = 0
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Highlight
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel2.Location = New System.Drawing.Point(-1, 18)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(704, 35)
        Me.Panel2.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.Highlight
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(225, 11)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(284, 17)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "EMPLOYEE PAYROLL COMPUTATION"
        '
        'MPFRM01EmmanuelleElimanco
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(704, 458)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "MPFRM01EmmanuelleElimanco"
        Me.Text = "EmElimanco Special Pizza"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.nudNo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cbPosition As System.Windows.Forms.ComboBox
    Friend WithEvents cb1 As System.Windows.Forms.ComboBox
    Friend WithEvents txtEmployee As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rdWidowed As System.Windows.Forms.RadioButton
    Friend WithEvents rdMarried As System.Windows.Forms.RadioButton
    Friend WithEvents rdSingle As System.Windows.Forms.RadioButton
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtNet As System.Windows.Forms.TextBox
    Friend WithEvents txtWith As System.Windows.Forms.TextBox
    Friend WithEvents txtSss As System.Windows.Forms.TextBox
    Friend WithEvents txtBasic As System.Windows.Forms.TextBox
    Friend WithEvents nudNo As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents btnCompute As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label

End Class
