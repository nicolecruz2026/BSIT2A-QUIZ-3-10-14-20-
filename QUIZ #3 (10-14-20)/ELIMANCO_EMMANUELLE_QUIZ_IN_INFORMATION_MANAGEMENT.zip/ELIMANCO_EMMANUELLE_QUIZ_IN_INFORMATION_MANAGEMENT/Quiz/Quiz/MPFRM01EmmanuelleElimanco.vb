﻿


Public Class MPFRM01EmmanuelleElimanco

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        cb1.Text = ""
        cbPosition.Text = ""
        txtBasic.Text = ""
        txtEmployee.Text = ""
        txtNet.Text = ""
        txtSss.Text = ""
        txtWith.Text = ""
        rdMarried.Checked = False
        rdSingle.Checked = False
        rdWidowed.Checked = False
        nudNo.Value = False

    End Sub

    Private Sub btnCompute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompute.Click
        Dim bp, sss, wt, np, tr, cb As Double
        If cb1.SelectedItem = "EN0001" Then
            cb = 500
        End If
        If cb1.SelectedItem = "EN0002" Then
            cb = 400
        End If
        If cb1.SelectedItem = "EN0003" Then
            cb = 300
        End If
        If rdSingle.Checked Then
            tr = 0.1
        End If
        If rdMarried.Checked Or rdWidowed.Checked Then
            tr = 0.05
        End If
        If bp >= 10000 Then
            sss = 0.07
        End If
        If bp >= 5000 Then
            sss = 0.05
        End If
        If bp >= 1000 Then
            sss = 0.03
        End If
        If bp <= 999 Then
            sss = 0.01
        End If
        bp = nudNo.Value * cb
        sss = bp * sss
        wt = bp * tr
        np = bp - (sss + wt)
        txtBasic.Text = bp
        txtSss.Text = sss
        txtWith.Text = wt
        txtNet.Text = np

    End Sub

    Private Sub cb1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb1.SelectedIndexChanged
        If cb1.SelectedItem = "EN0001" Then
            txtEmployee.Text = "Emmanuelle Elimanco"
            cbPosition.Text = "PC-A"
        End If
        If cb1.SelectedItem = "EN0002" Then
            txtEmployee.Text = "Maricko Alas"
            cbPosition.Text = "PC-B"
        End If
        If cb1.SelectedItem = "EN0003" Then
            txtEmployee.Text = "Janlo Salazar"
            cbPosition.Text = "PC-C"
        End If

    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        End
    End Sub
End Class
