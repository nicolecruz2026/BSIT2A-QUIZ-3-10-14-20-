﻿
Public Class MPFRM02EmmanuelleElimanco
    Private size, crustSize, drinks As String
    Private toppings As String = ""

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnToppings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnToppings.Click
       
        cbBlack.Checked = False
        cbCheese.Checked = False
        cbGreen.Checked = False
        cbMushroom.Checked = False
        cbOnions.Checked = False
        cbTomatoes.Checked = False
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        rdbSmall.Checked = False
        rdbMedium.Checked = False
        rdbLarge.Checked = False
        rdbThin.Checked = False
        rdbThick.Checked = False
        rdbSoft.Checked = False
        rdbFruit.Checked = False
        rdbCoffee.Checked = False
        rdbDine.Checked = False
        rdbTake.Checked = False
        cbBlack.Checked = False
        cbCheese.Checked = False
        cbGreen.Checked = False
        cbMushroom.Checked = False
        cbOnions.Checked = False
        cbTomatoes.Checked = False
        txtDrinks.Text = ""
        txtExtra.Text = ""
        txtPizza.Text = ""
        txtTotal.Text = ""
    End Sub

    Private Sub btnCompute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCompute.Click
        Dim price, crust, drinkPrice, tPrice As Double

        tPrice = 0

        If rdbSmall.Checked = True Then
            price = 100.0
            size = "Small"
        ElseIf rdbMedium.Checked = True Then
            price = 150.0
            size = "Medium"
        ElseIf rdbLarge.Checked = True Then
            price = 200.0
            size = "Large"
        End If

        If rdbThin.Checked = True Then
            crust = price + price
            crustSize = "Thin Crust"
        ElseIf rdbThick.Checked = True Then
            crust = price + price + (price * 0.5)
            crustSize = "Thick Crust"
        End If

        txtPizza.Text = crust
        If rdbSoft.Checked = True Then
            drinkPrice = 20
            drinks = "Softdrinks"
        ElseIf rdbFruit.Checked = True Then
            drinkPrice = 15
            drinks = "Fruit Juice"
        ElseIf rdbCoffee.Checked = True Then
            drinkPrice = 25
            drinks = "Coffee Chocolate"
        End If
        txtDrinks.Text = drinkPrice

        If cbCheese.Checked = True Then
            tPrice = tPrice + 10
            toppings = toppings + Environment.NewLine + "Extra Cheese"
        End If
        If cbMushroom.Checked = True Then
            tPrice = tPrice + 10
            toppings = toppings + Environment.NewLine + "Mushroom"
        End If
        If cbBlack.Checked = True Then
            tPrice = tPrice + 10
            toppings = toppings + Environment.NewLine + "Black Olives"
        End If
        If cbOnions.Checked = True Then
            tPrice = tPrice + 10
            toppings = toppings + Environment.NewLine + "Onions"
        End If
        If cbGreen.Checked = True Then
            tPrice = tPrice + 10
            toppings = toppings + Environment.NewLine + "Green Peppers"
        End If
        If cbTomatoes.Checked = True Then
            tPrice = tPrice + 10
            toppings = toppings + Environment.NewLine + "Tomatoes"
        End If

        txtExtra.Text = tPrice

        txtTotal.Text = crust + drinkPrice + tPrice
    End Sub

    Private Sub btnBuild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuild.Click
        Dim msg As String

        msg = String.Format("Your Pizza " + Environment.NewLine)

        MessageBox.Show("Your Pizza " + Environment.NewLine + Environment.NewLine + "Dine in" + Environment.NewLine + size + Environment.NewLine + crustSize + Environment.NewLine + toppings)
    End Sub

    Private Sub MPFRM02EmmanuelleElimanco_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label5.Text = TimeOfDay
        Label6.Text = Today.ToString("ddd, MMM d yyyy")
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click

    End Sub
End Class