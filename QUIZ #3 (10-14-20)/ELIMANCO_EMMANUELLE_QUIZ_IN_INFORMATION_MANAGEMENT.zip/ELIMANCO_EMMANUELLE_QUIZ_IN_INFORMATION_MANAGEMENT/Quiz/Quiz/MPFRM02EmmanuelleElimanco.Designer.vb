﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM02EmmanuelleElimanco
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdbLarge = New System.Windows.Forms.RadioButton()
        Me.rdbMedium = New System.Windows.Forms.RadioButton()
        Me.rdbSmall = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rdbThin = New System.Windows.Forms.RadioButton()
        Me.rdbThick = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rdbCoffee = New System.Windows.Forms.RadioButton()
        Me.rdbFruit = New System.Windows.Forms.RadioButton()
        Me.rdbSoft = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.cbTomatoes = New System.Windows.Forms.CheckBox()
        Me.cbGreen = New System.Windows.Forms.CheckBox()
        Me.cbOnions = New System.Windows.Forms.CheckBox()
        Me.cbBlack = New System.Windows.Forms.CheckBox()
        Me.cbMushroom = New System.Windows.Forms.CheckBox()
        Me.cbCheese = New System.Windows.Forms.CheckBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtPizza = New System.Windows.Forms.TextBox()
        Me.txtDrinks = New System.Windows.Forms.TextBox()
        Me.txtExtra = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.rdbDine = New System.Windows.Forms.RadioButton()
        Me.rdbTake = New System.Windows.Forms.RadioButton()
        Me.btnBuild = New System.Windows.Forms.Button()
        Me.btnToppings = New System.Windows.Forms.Button()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdbLarge)
        Me.GroupBox1.Controls.Add(Me.rdbMedium)
        Me.GroupBox1.Controls.Add(Me.rdbSmall)
        Me.GroupBox1.Location = New System.Drawing.Point(23, 53)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(227, 184)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Size"
        '
        'rdbLarge
        '
        Me.rdbLarge.AutoSize = True
        Me.rdbLarge.Location = New System.Drawing.Point(23, 130)
        Me.rdbLarge.Name = "rdbLarge"
        Me.rdbLarge.Size = New System.Drawing.Size(66, 21)
        Me.rdbLarge.TabIndex = 2
        Me.rdbLarge.TabStop = True
        Me.rdbLarge.Text = "Large"
        Me.rdbLarge.UseVisualStyleBackColor = True
        '
        'rdbMedium
        '
        Me.rdbMedium.AutoSize = True
        Me.rdbMedium.Location = New System.Drawing.Point(23, 84)
        Me.rdbMedium.Name = "rdbMedium"
        Me.rdbMedium.Size = New System.Drawing.Size(78, 21)
        Me.rdbMedium.TabIndex = 1
        Me.rdbMedium.TabStop = True
        Me.rdbMedium.Text = "Medium"
        Me.rdbMedium.UseVisualStyleBackColor = True
        '
        'rdbSmall
        '
        Me.rdbSmall.AutoSize = True
        Me.rdbSmall.Location = New System.Drawing.Point(23, 38)
        Me.rdbSmall.Name = "rdbSmall"
        Me.rdbSmall.Size = New System.Drawing.Size(63, 21)
        Me.rdbSmall.TabIndex = 0
        Me.rdbSmall.TabStop = True
        Me.rdbSmall.Text = "Small"
        Me.rdbSmall.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rdbThin)
        Me.GroupBox2.Controls.Add(Me.rdbThick)
        Me.GroupBox2.Location = New System.Drawing.Point(23, 261)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(227, 111)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Crust Type"
        '
        'rdbThin
        '
        Me.rdbThin.AutoSize = True
        Me.rdbThin.Location = New System.Drawing.Point(23, 31)
        Me.rdbThin.Name = "rdbThin"
        Me.rdbThin.Size = New System.Drawing.Size(94, 21)
        Me.rdbThin.TabIndex = 3
        Me.rdbThin.TabStop = True
        Me.rdbThin.Text = "Thin Crust"
        Me.rdbThin.UseVisualStyleBackColor = True
        '
        'rdbThick
        '
        Me.rdbThick.AutoSize = True
        Me.rdbThick.Location = New System.Drawing.Point(23, 68)
        Me.rdbThick.Name = "rdbThick"
        Me.rdbThick.Size = New System.Drawing.Size(100, 21)
        Me.rdbThick.TabIndex = 4
        Me.rdbThick.TabStop = True
        Me.rdbThick.Text = "Thick Crust"
        Me.rdbThick.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rdbCoffee)
        Me.GroupBox3.Controls.Add(Me.rdbFruit)
        Me.GroupBox3.Controls.Add(Me.rdbSoft)
        Me.GroupBox3.Location = New System.Drawing.Point(23, 378)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(227, 184)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Drinks"
        '
        'rdbCoffee
        '
        Me.rdbCoffee.AutoSize = True
        Me.rdbCoffee.Location = New System.Drawing.Point(23, 142)
        Me.rdbCoffee.Name = "rdbCoffee"
        Me.rdbCoffee.Size = New System.Drawing.Size(137, 21)
        Me.rdbCoffee.TabIndex = 7
        Me.rdbCoffee.TabStop = True
        Me.rdbCoffee.Text = "Coffee/Chocolate"
        Me.rdbCoffee.UseVisualStyleBackColor = True
        '
        'rdbFruit
        '
        Me.rdbFruit.AutoSize = True
        Me.rdbFruit.Location = New System.Drawing.Point(23, 93)
        Me.rdbFruit.Name = "rdbFruit"
        Me.rdbFruit.Size = New System.Drawing.Size(94, 21)
        Me.rdbFruit.TabIndex = 6
        Me.rdbFruit.TabStop = True
        Me.rdbFruit.Text = "Fruit Juice"
        Me.rdbFruit.UseVisualStyleBackColor = True
        '
        'rdbSoft
        '
        Me.rdbSoft.AutoSize = True
        Me.rdbSoft.Location = New System.Drawing.Point(23, 42)
        Me.rdbSoft.Name = "rdbSoft"
        Me.rdbSoft.Size = New System.Drawing.Size(98, 21)
        Me.rdbSoft.TabIndex = 5
        Me.rdbSoft.TabStop = True
        Me.rdbSoft.Text = "Soft Drinks"
        Me.rdbSoft.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.cbTomatoes)
        Me.GroupBox4.Controls.Add(Me.cbGreen)
        Me.GroupBox4.Controls.Add(Me.cbOnions)
        Me.GroupBox4.Controls.Add(Me.cbBlack)
        Me.GroupBox4.Controls.Add(Me.cbMushroom)
        Me.GroupBox4.Controls.Add(Me.cbCheese)
        Me.GroupBox4.Location = New System.Drawing.Point(269, 53)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(355, 195)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Extra Toppings"
        '
        'cbTomatoes
        '
        Me.cbTomatoes.AutoSize = True
        Me.cbTomatoes.Location = New System.Drawing.Point(211, 130)
        Me.cbTomatoes.Name = "cbTomatoes"
        Me.cbTomatoes.Size = New System.Drawing.Size(93, 21)
        Me.cbTomatoes.TabIndex = 5
        Me.cbTomatoes.Text = "Tomatoes"
        Me.cbTomatoes.UseVisualStyleBackColor = True
        '
        'cbGreen
        '
        Me.cbGreen.AutoSize = True
        Me.cbGreen.Location = New System.Drawing.Point(211, 84)
        Me.cbGreen.Name = "cbGreen"
        Me.cbGreen.Size = New System.Drawing.Size(127, 21)
        Me.cbGreen.TabIndex = 4
        Me.cbGreen.Text = "Green Peppers"
        Me.cbGreen.UseVisualStyleBackColor = True
        '
        'cbOnions
        '
        Me.cbOnions.AutoSize = True
        Me.cbOnions.Location = New System.Drawing.Point(211, 38)
        Me.cbOnions.Name = "cbOnions"
        Me.cbOnions.Size = New System.Drawing.Size(75, 21)
        Me.cbOnions.TabIndex = 3
        Me.cbOnions.Text = "Onions"
        Me.cbOnions.UseVisualStyleBackColor = True
        '
        'cbBlack
        '
        Me.cbBlack.AutoSize = True
        Me.cbBlack.Location = New System.Drawing.Point(39, 131)
        Me.cbBlack.Name = "cbBlack"
        Me.cbBlack.Size = New System.Drawing.Size(107, 21)
        Me.cbBlack.TabIndex = 2
        Me.cbBlack.Text = "Black Olives"
        Me.cbBlack.UseVisualStyleBackColor = True
        '
        'cbMushroom
        '
        Me.cbMushroom.AutoSize = True
        Me.cbMushroom.Location = New System.Drawing.Point(39, 85)
        Me.cbMushroom.Name = "cbMushroom"
        Me.cbMushroom.Size = New System.Drawing.Size(132, 21)
        Me.cbMushroom.TabIndex = 1
        Me.cbMushroom.Text = "Extra Mushroom"
        Me.cbMushroom.UseVisualStyleBackColor = True
        '
        'cbCheese
        '
        Me.cbCheese.AutoSize = True
        Me.cbCheese.Location = New System.Drawing.Point(39, 39)
        Me.cbCheese.Name = "cbCheese"
        Me.cbCheese.Size = New System.Drawing.Size(114, 21)
        Me.cbCheese.TabIndex = 0
        Me.cbCheese.Text = "Extra Cheese"
        Me.cbCheese.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Button8)
        Me.GroupBox5.Controls.Add(Me.Button7)
        Me.GroupBox5.Controls.Add(Me.txtTotal)
        Me.GroupBox5.Controls.Add(Me.txtPizza)
        Me.GroupBox5.Controls.Add(Me.txtDrinks)
        Me.GroupBox5.Controls.Add(Me.txtExtra)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Location = New System.Drawing.Point(269, 329)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(253, 233)
        Me.GroupBox5.TabIndex = 4
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Amount"
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(-90, -47)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(84, 55)
        Me.Button8.TabIndex = 14
        Me.Button8.Text = "Button5"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(-102, -47)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(84, 55)
        Me.Button7.TabIndex = 14
        Me.Button7.Text = "Button5"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'txtTotal
        '
        Me.txtTotal.Location = New System.Drawing.Point(128, 180)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(119, 22)
        Me.txtTotal.TabIndex = 7
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPizza
        '
        Me.txtPizza.Location = New System.Drawing.Point(128, 26)
        Me.txtPizza.Name = "txtPizza"
        Me.txtPizza.Size = New System.Drawing.Size(119, 22)
        Me.txtPizza.TabIndex = 6
        Me.txtPizza.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtDrinks
        '
        Me.txtDrinks.Location = New System.Drawing.Point(128, 105)
        Me.txtDrinks.Name = "txtDrinks"
        Me.txtDrinks.Size = New System.Drawing.Size(119, 22)
        Me.txtDrinks.TabIndex = 5
        Me.txtDrinks.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtExtra
        '
        Me.txtExtra.Location = New System.Drawing.Point(128, 63)
        Me.txtExtra.Name = "txtExtra"
        Me.txtExtra.Size = New System.Drawing.Size(119, 22)
        Me.txtExtra.TabIndex = 4
        Me.txtExtra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(11, 180)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "TOTAL :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 108)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Drinks :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(111, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Extra Toppings :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pizza :"
        '
        'rdbDine
        '
        Me.rdbDine.AutoSize = True
        Me.rdbDine.Location = New System.Drawing.Point(23, 583)
        Me.rdbDine.Name = "rdbDine"
        Me.rdbDine.Size = New System.Drawing.Size(73, 21)
        Me.rdbDine.TabIndex = 8
        Me.rdbDine.TabStop = True
        Me.rdbDine.Text = "Dine In"
        Me.rdbDine.UseVisualStyleBackColor = True
        '
        'rdbTake
        '
        Me.rdbTake.AutoSize = True
        Me.rdbTake.Location = New System.Drawing.Point(144, 583)
        Me.rdbTake.Name = "rdbTake"
        Me.rdbTake.Size = New System.Drawing.Size(88, 21)
        Me.rdbTake.TabIndex = 9
        Me.rdbTake.TabStop = True
        Me.rdbTake.Text = "Take Out"
        Me.rdbTake.UseVisualStyleBackColor = True
        '
        'btnBuild
        '
        Me.btnBuild.Location = New System.Drawing.Point(292, 269)
        Me.btnBuild.Name = "btnBuild"
        Me.btnBuild.Size = New System.Drawing.Size(136, 44)
        Me.btnBuild.TabIndex = 10
        Me.btnBuild.Text = "Build Pizza"
        Me.btnBuild.UseVisualStyleBackColor = True
        '
        'btnToppings
        '
        Me.btnToppings.Location = New System.Drawing.Point(465, 269)
        Me.btnToppings.Name = "btnToppings"
        Me.btnToppings.Size = New System.Drawing.Size(136, 44)
        Me.btnToppings.TabIndex = 11
        Me.btnToppings.Text = "Clear Toppings"
        Me.btnToppings.UseVisualStyleBackColor = True
        '
        'btnCompute
        '
        Me.btnCompute.Location = New System.Drawing.Point(540, 336)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(84, 55)
        Me.btnCompute.TabIndex = 12
        Me.btnCompute.Text = "COMPUTE"
        Me.btnCompute.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(540, 420)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(84, 55)
        Me.btnClear.TabIndex = 13
        Me.btnClear.Text = "CLEAR ALL"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(540, 503)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(84, 55)
        Me.btnExit.TabIndex = 14
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(475, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(0, 29)
        Me.Label5.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(23, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 29)
        Me.Label6.TabIndex = 16
        '
        'MPFRM02EmmanuelleElimanco
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(639, 628)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCompute)
        Me.Controls.Add(Me.btnToppings)
        Me.Controls.Add(Me.btnBuild)
        Me.Controls.Add(Me.rdbDine)
        Me.Controls.Add(Me.rdbTake)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "MPFRM02EmmanuelleElimanco"
        Me.Text = "EMPLOYEE PAYROLL COMPUTATION"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdbLarge As System.Windows.Forms.RadioButton
    Friend WithEvents rdbMedium As System.Windows.Forms.RadioButton
    Friend WithEvents rdbSmall As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rdbThin As System.Windows.Forms.RadioButton
    Friend WithEvents rdbThick As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rdbCoffee As System.Windows.Forms.RadioButton
    Friend WithEvents rdbFruit As System.Windows.Forms.RadioButton
    Friend WithEvents rdbSoft As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents cbTomatoes As System.Windows.Forms.CheckBox
    Friend WithEvents cbGreen As System.Windows.Forms.CheckBox
    Friend WithEvents cbOnions As System.Windows.Forms.CheckBox
    Friend WithEvents cbBlack As System.Windows.Forms.CheckBox
    Friend WithEvents cbMushroom As System.Windows.Forms.CheckBox
    Friend WithEvents cbCheese As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents rdbDine As System.Windows.Forms.RadioButton
    Friend WithEvents rdbTake As System.Windows.Forms.RadioButton
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtPizza As System.Windows.Forms.TextBox
    Friend WithEvents txtDrinks As System.Windows.Forms.TextBox
    Friend WithEvents txtExtra As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnBuild As System.Windows.Forms.Button
    Friend WithEvents btnToppings As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents btnCompute As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
