﻿Public Class MPFRM02MeljunBalon

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = Today.ToString("dddd, MMMM dd, yyyy")
        Label2.Text = TimeOfDay
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim subject As String
        subject = ""
        If RadioButton9.Checked = True Then
            subject = subject + RadioButton9.Text + vbNewLine
        End If
        If RadioButton10.Checked = True Then
            subject = subject + RadioButton10.Text + vbNewLine
        End If
        If RadioButton1.Checked = True Then
            subject = subject + RadioButton1.Text + vbNewLine
        End If
        If RadioButton2.Checked = True Then
            subject = subject + RadioButton2.Text + vbNewLine
        End If
        If RadioButton3.Checked = True Then
            subject = subject + RadioButton3.Text + vbNewLine
        End If
        If RadioButton4.Checked = True Then
            subject = subject + RadioButton4.Text + vbNewLine
        End If
        If RadioButton5.Checked = True Then
            subject = subject + RadioButton5.Text + vbNewLine
        End If
        If RadioButton6.Checked = True Then
            subject = subject + RadioButton6.Text + vbNewLine
        End If
        If RadioButton7.Checked = True Then
            subject = subject + RadioButton7.Text + vbNewLine
        End If
        If RadioButton8.Checked = True Then
            subject = subject + RadioButton8.Text + vbNewLine
        End If
        If CheckBox1.Checked Then
            subject = subject + CheckBox1.Text + vbNewLine
        End If
        If CheckBox2.Checked Then
            subject = subject + CheckBox2.Text + vbNewLine
        End If
        If CheckBox3.Checked Then
            subject = subject + CheckBox3.Text + vbNewLine
        End If
        If CheckBox4.Checked Then
            subject = subject + CheckBox4.Text + vbNewLine
        End If
        If CheckBox5.Checked Then
            subject = subject + CheckBox5.Text + vbNewLine
        End If
        If CheckBox6.Checked Then
            subject = subject + CheckBox6.Text + vbNewLine
        End If
        MessageBox.Show(subject, "Your Pizza")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        CheckBox3.Checked = False
        CheckBox4.Checked = False
        CheckBox5.Checked = False
        CheckBox6.Checked = False
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim size, type, drinks, total As Double
        Dim sum As Double
        Const extra1 As Double = 10
        Const extra2 As Double = 10
        Const extra3 As Double = 10
        Const extra4 As Double = 10
        Const extra5 As Double = 10
        Const extra6 As Double = 10

        If RadioButton1.Checked = True Then
            size = 100
        ElseIf RadioButton2.Checked = True Then
            size = 150
        ElseIf RadioButton3.Checked = True Then
            size = 200
        End If
        If RadioButton4.Checked = True Then
            type = 0
        ElseIf RadioButton5.Checked = True Then
            type = size * 0.5
        End If
        size = size + type
        TextBox1.Text = Format(size, "###,###.00")
        If CheckBox1.Checked = True Then
            sum = sum + extra1
        End If
        If CheckBox2.Checked = True Then
            sum = sum + extra2
        End If
        If CheckBox3.Checked = True Then
            sum = sum + extra3
        End If
        If CheckBox4.Checked = True Then
            sum = sum + extra4
        End If
        If CheckBox5.Checked = True Then
            sum = sum + extra5
        End If
        If CheckBox6.Checked = True Then
            sum = sum + extra6
        End If
        TextBox2.Text = sum.ToString & ".00"
        If RadioButton6.Checked = True Then
            drinks = 20
        ElseIf RadioButton7.Checked = True Then
            drinks = 15
        ElseIf RadioButton8.Checked = True Then
            drinks = 25
        End If
        TextBox3.Text = Format(drinks, "###,###.00")
        total = size + sum + drinks
        TextBox4.Text = Format(total, "###,###.00")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
        RadioButton4.Checked = False
        RadioButton5.Checked = False
        RadioButton6.Checked = False
        RadioButton7.Checked = False
        RadioButton8.Checked = False
        RadioButton9.Checked = False
        RadioButton10.Checked = False
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        CheckBox3.Checked = False
        CheckBox4.Checked = False
        CheckBox5.Checked = False
        CheckBox6.Checked = False
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Close()
    End Sub
End Class