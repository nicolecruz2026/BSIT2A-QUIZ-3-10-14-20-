﻿Public Class MPFRM02CarlNumos

    
   
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label5.Text = Today.DayOfWeek.ToString + Today.ToString(", MMMM dd, yyyy")
        Label6.Text = TimeOfDay
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        RdSmall.Checked = False
        RdMedium.Checked = False
        RdLarge.Checked = False
        RdThincrust.Checked = False
        RdThickcrust.Checked = False
        RdSoftdrinks.Checked = False
        RdFruitjuice.Checked = False
        RdCofchoc.Checked = False
        Rddine.Checked = False
        Rdtake.Checked = False


        ChkExtracheese.Checked = False
        ChkGreenpeppers.Checked = False
        ChkMush.Checked = False
        Chkblack.Checked = False
        ChkTomato.Checked = False
        ChkOnion.Checked = False



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Piz As String
        Piz = ("")
        If Rddine.Checked Then
            Piz = Piz + Rddine.Text + vbNewLine
        End If
        If Rdtake.Checked Then
            Piz = Piz + Rdtake.Text + vbNewLine
        End If
        If RdSmall.Checked Then
            Piz = Piz + RdSmall.Text + vbNewLine
        End If
        If RdMedium.Checked Then
            Piz = Piz + RdMedium.Text + vbNewLine
        End If
        If RdLarge.Checked Then
            Piz = Piz + RdLarge.Text + vbNewLine
        End If
        If RdThincrust.Checked Then
            Piz = Piz + RdThincrust.Text + vbNewLine
        End If
        If RdThickcrust.Checked Then
            Piz = Piz + RdThickcrust.Text + vbNewLine
        End If
        If RdSoftdrinks.Checked Then
            Piz = Piz + RdSoftdrinks.Text + vbNewLine
        End If
        If RdFruitjuice.Checked Then
            Piz = Piz + RdFruitjuice.Text + vbNewLine
        End If
        If RdCofchoc.Checked Then
            Piz = Piz + RdCofchoc.Text + vbNewLine
        End If
        If ChkExtracheese.Checked Then
            Piz = Piz + ChkExtracheese.Text + vbNewLine
        End If
        If ChkOnion.Checked Then
            Piz = Piz + ChkOnion.Text + vbNewLine
        End If
        If ChkMush.Checked Then
            Piz = Piz + ChkMush.Text + vbNewLine
        End If
        If ChkGreenpeppers.Checked Then
            Piz = Piz + ChkGreenpeppers.Text + vbNewLine
        End If
        If Chkblack.Checked Then
            Piz = Piz + Chkblack.Text + vbNewLine
        End If
        If ChkTomato.Checked Then
            Piz = Piz + ChkTomato.Text + vbNewLine
        End If


        MessageBox.Show(vbNewLine + Piz, "Your Pizza")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim price, crust, drinkPrice, tPrice, Totals As Double
        tPrice = 0

        If RdSmall.Checked = True Then
            price = 100.0
        ElseIf RdMedium.Checked = True Then
            price = 150.0
        ElseIf RdLarge.Checked = True Then
            price = 200.0
        End If

        If RdThincrust.Checked = True Then
            crust = price
        ElseIf RdThickcrust.Checked = True Then
            crust = price + (price * 0.5)
        End If

        TextBox1.Text = crust
        If RdSoftdrinks.Checked = True Then
            drinkPrice = 20
        ElseIf RdFruitjuice.Checked = True Then
            drinkPrice = 15
        ElseIf RdCofchoc.Checked = True Then
            drinkPrice = 25
        End If
        TextBox3.Text = drinkPrice

        If ChkExtracheese.Checked = True Then
            tPrice = tPrice + 10
        End If
        If ChkMush.Checked = True Then
            tPrice = tPrice + 10
        End If
        If Chkblack.Checked = True Then
            tPrice = tPrice + 10
        End If
        If ChkOnion.Checked = True Then
            tPrice = tPrice + 10
        End If
        If ChkGreenpeppers.Checked = True Then
            tPrice = tPrice + 10
        End If
        If ChkTomato.Checked = True Then
            tPrice = tPrice + 10
        End If

        TextBox2.Text = tPrice

        Totals = crust + tPrice + drinkPrice
        TextBox4.Text = Totals


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        RdSmall.Checked = False
        RdMedium.Checked = False
        RdLarge.Checked = False
        RdThincrust.Checked = False
        RdThickcrust.Checked = False
        RdSoftdrinks.Checked = False
        RdFruitjuice.Checked = False
        RdCofchoc.Checked = False
        Rddine.Checked = False
        Rdtake.Checked = False


        ChkExtracheese.Checked = False
        ChkGreenpeppers.Checked = False
        ChkMush.Checked = False
        Chkblack.Checked = False
        ChkTomato.Checked = False
        ChkOnion.Checked = False

        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Close()
    End Sub
End Class