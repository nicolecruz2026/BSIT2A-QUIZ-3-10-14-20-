﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPFRM02CarlNumos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RdLarge = New System.Windows.Forms.RadioButton()
        Me.RdMedium = New System.Windows.Forms.RadioButton()
        Me.RdSmall = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RdThickcrust = New System.Windows.Forms.RadioButton()
        Me.RdThincrust = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.RdCofchoc = New System.Windows.Forms.RadioButton()
        Me.RdFruitjuice = New System.Windows.Forms.RadioButton()
        Me.RdSoftdrinks = New System.Windows.Forms.RadioButton()
        Me.Rddine = New System.Windows.Forms.RadioButton()
        Me.Rdtake = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.ChkTomato = New System.Windows.Forms.CheckBox()
        Me.ChkGreenpeppers = New System.Windows.Forms.CheckBox()
        Me.ChkOnion = New System.Windows.Forms.CheckBox()
        Me.Chkblack = New System.Windows.Forms.CheckBox()
        Me.ChkMush = New System.Windows.Forms.CheckBox()
        Me.ChkExtracheese = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RdLarge)
        Me.GroupBox1.Controls.Add(Me.RdMedium)
        Me.GroupBox1.Controls.Add(Me.RdSmall)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 39)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(166, 100)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Size"
        '
        'RdLarge
        '
        Me.RdLarge.AutoSize = True
        Me.RdLarge.Location = New System.Drawing.Point(25, 65)
        Me.RdLarge.Name = "RdLarge"
        Me.RdLarge.Size = New System.Drawing.Size(52, 17)
        Me.RdLarge.TabIndex = 2
        Me.RdLarge.TabStop = True
        Me.RdLarge.Text = "Large"
        Me.RdLarge.UseVisualStyleBackColor = True
        '
        'RdMedium
        '
        Me.RdMedium.AutoSize = True
        Me.RdMedium.Location = New System.Drawing.Point(25, 42)
        Me.RdMedium.Name = "RdMedium"
        Me.RdMedium.Size = New System.Drawing.Size(62, 17)
        Me.RdMedium.TabIndex = 1
        Me.RdMedium.TabStop = True
        Me.RdMedium.Text = "Medium"
        Me.RdMedium.UseVisualStyleBackColor = True
        '
        'RdSmall
        '
        Me.RdSmall.AutoSize = True
        Me.RdSmall.Location = New System.Drawing.Point(25, 20)
        Me.RdSmall.Name = "RdSmall"
        Me.RdSmall.Size = New System.Drawing.Size(50, 17)
        Me.RdSmall.TabIndex = 0
        Me.RdSmall.TabStop = True
        Me.RdSmall.Text = "Small"
        Me.RdSmall.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RdThickcrust)
        Me.GroupBox2.Controls.Add(Me.RdThincrust)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 145)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(166, 100)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Crust Type"
        '
        'RdThickcrust
        '
        Me.RdThickcrust.AutoSize = True
        Me.RdThickcrust.Location = New System.Drawing.Point(38, 77)
        Me.RdThickcrust.Name = "RdThickcrust"
        Me.RdThickcrust.Size = New System.Drawing.Size(79, 17)
        Me.RdThickcrust.TabIndex = 2
        Me.RdThickcrust.TabStop = True
        Me.RdThickcrust.Text = "Thick Crust"
        Me.RdThickcrust.UseVisualStyleBackColor = True
        '
        'RdThincrust
        '
        Me.RdThincrust.AutoSize = True
        Me.RdThincrust.Location = New System.Drawing.Point(38, 42)
        Me.RdThincrust.Name = "RdThincrust"
        Me.RdThincrust.Size = New System.Drawing.Size(73, 17)
        Me.RdThincrust.TabIndex = 1
        Me.RdThincrust.TabStop = True
        Me.RdThincrust.Text = "Thin Crust"
        Me.RdThincrust.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.RdCofchoc)
        Me.GroupBox3.Controls.Add(Me.RdFruitjuice)
        Me.GroupBox3.Controls.Add(Me.RdSoftdrinks)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 267)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(166, 100)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Drinks"
        '
        'RdCofchoc
        '
        Me.RdCofchoc.AutoSize = True
        Me.RdCofchoc.Location = New System.Drawing.Point(38, 77)
        Me.RdCofchoc.Name = "RdCofchoc"
        Me.RdCofchoc.Size = New System.Drawing.Size(109, 17)
        Me.RdCofchoc.TabIndex = 3
        Me.RdCofchoc.TabStop = True
        Me.RdCofchoc.Text = "Coffee/Chocolate"
        Me.RdCofchoc.UseVisualStyleBackColor = True
        '
        'RdFruitjuice
        '
        Me.RdFruitjuice.AutoSize = True
        Me.RdFruitjuice.Location = New System.Drawing.Point(38, 54)
        Me.RdFruitjuice.Name = "RdFruitjuice"
        Me.RdFruitjuice.Size = New System.Drawing.Size(73, 17)
        Me.RdFruitjuice.TabIndex = 2
        Me.RdFruitjuice.TabStop = True
        Me.RdFruitjuice.Text = "Fruit Juice"
        Me.RdFruitjuice.UseVisualStyleBackColor = True
        '
        'RdSoftdrinks
        '
        Me.RdSoftdrinks.AutoSize = True
        Me.RdSoftdrinks.Location = New System.Drawing.Point(38, 31)
        Me.RdSoftdrinks.Name = "RdSoftdrinks"
        Me.RdSoftdrinks.Size = New System.Drawing.Size(77, 17)
        Me.RdSoftdrinks.TabIndex = 1
        Me.RdSoftdrinks.TabStop = True
        Me.RdSoftdrinks.Text = "Soft Drinks"
        Me.RdSoftdrinks.UseVisualStyleBackColor = True
        '
        'Rddine
        '
        Me.Rddine.AutoSize = True
        Me.Rddine.Location = New System.Drawing.Point(12, 373)
        Me.Rddine.Name = "Rddine"
        Me.Rddine.Size = New System.Drawing.Size(58, 17)
        Me.Rddine.TabIndex = 4
        Me.Rddine.TabStop = True
        Me.Rddine.Text = "Dine-in"
        Me.Rddine.UseVisualStyleBackColor = True
        '
        'Rdtake
        '
        Me.Rdtake.AutoSize = True
        Me.Rdtake.Location = New System.Drawing.Point(108, 373)
        Me.Rdtake.Name = "Rdtake"
        Me.Rdtake.Size = New System.Drawing.Size(70, 17)
        Me.Rdtake.TabIndex = 5
        Me.Rdtake.TabStop = True
        Me.Rdtake.Text = "Take-Out"
        Me.Rdtake.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.ChkTomato)
        Me.GroupBox4.Controls.Add(Me.ChkGreenpeppers)
        Me.GroupBox4.Controls.Add(Me.ChkOnion)
        Me.GroupBox4.Controls.Add(Me.Chkblack)
        Me.GroupBox4.Controls.Add(Me.ChkMush)
        Me.GroupBox4.Controls.Add(Me.ChkExtracheese)
        Me.GroupBox4.Location = New System.Drawing.Point(209, 39)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(275, 100)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Extra Toppings"
        '
        'ChkTomato
        '
        Me.ChkTomato.AutoSize = True
        Me.ChkTomato.Location = New System.Drawing.Point(140, 77)
        Me.ChkTomato.Name = "ChkTomato"
        Me.ChkTomato.Size = New System.Drawing.Size(73, 17)
        Me.ChkTomato.TabIndex = 5
        Me.ChkTomato.Text = "Tomatoes"
        Me.ChkTomato.UseVisualStyleBackColor = True
        '
        'ChkGreenpeppers
        '
        Me.ChkGreenpeppers.AutoSize = True
        Me.ChkGreenpeppers.Location = New System.Drawing.Point(140, 47)
        Me.ChkGreenpeppers.Name = "ChkGreenpeppers"
        Me.ChkGreenpeppers.Size = New System.Drawing.Size(97, 17)
        Me.ChkGreenpeppers.TabIndex = 4
        Me.ChkGreenpeppers.Text = "Green Peppers"
        Me.ChkGreenpeppers.UseVisualStyleBackColor = True
        '
        'ChkOnion
        '
        Me.ChkOnion.AutoSize = True
        Me.ChkOnion.Location = New System.Drawing.Point(140, 21)
        Me.ChkOnion.Name = "ChkOnion"
        Me.ChkOnion.Size = New System.Drawing.Size(59, 17)
        Me.ChkOnion.TabIndex = 3
        Me.ChkOnion.Text = "Onions"
        Me.ChkOnion.UseVisualStyleBackColor = True
        '
        'Chkblack
        '
        Me.Chkblack.AutoSize = True
        Me.Chkblack.Location = New System.Drawing.Point(7, 77)
        Me.Chkblack.Name = "Chkblack"
        Me.Chkblack.Size = New System.Drawing.Size(85, 17)
        Me.Chkblack.TabIndex = 2
        Me.Chkblack.Text = "Black Olives"
        Me.Chkblack.UseVisualStyleBackColor = True
        '
        'ChkMush
        '
        Me.ChkMush.AutoSize = True
        Me.ChkMush.Location = New System.Drawing.Point(6, 47)
        Me.ChkMush.Name = "ChkMush"
        Me.ChkMush.Size = New System.Drawing.Size(75, 17)
        Me.ChkMush.TabIndex = 1
        Me.ChkMush.Text = "Mushroom"
        Me.ChkMush.UseVisualStyleBackColor = True
        '
        'ChkExtracheese
        '
        Me.ChkExtracheese.AutoSize = True
        Me.ChkExtracheese.Location = New System.Drawing.Point(7, 20)
        Me.ChkExtracheese.Name = "ChkExtracheese"
        Me.ChkExtracheese.Size = New System.Drawing.Size(89, 17)
        Me.ChkExtracheese.TabIndex = 0
        Me.ChkExtracheese.Text = "Extra Cheese"
        Me.ChkExtracheese.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(209, 156)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(126, 23)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Build Pizza"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(349, 156)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(126, 23)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Clear Toppings"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.TextBox3)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.TextBox2)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Controls.Add(Me.TextBox1)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Location = New System.Drawing.Point(215, 207)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Amount"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(94, 74)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Drinks"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(94, 45)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Extra Toppings"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(94, 19)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pizza"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.TextBox4)
        Me.GroupBox6.Controls.Add(Me.Label4)
        Me.GroupBox6.Location = New System.Drawing.Point(215, 330)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(200, 53)
        Me.GroupBox6.TabIndex = 9
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Total"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(94, 19)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(18, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Total"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(421, 215)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 40)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "Compute"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(421, 281)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 40)
        Me.Button4.TabIndex = 11
        Me.Button4.Text = "Clear All"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(421, 341)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 40)
        Me.Button5.TabIndex = 12
        Me.Button5.Text = "Close"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(31, 17)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 13)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Label5"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(407, 17)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(39, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Label6"
        '
        'MPFRM02CarlNumos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(506, 395)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.Rdtake)
        Me.Controls.Add(Me.Rddine)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "MPFRM02CarlNumos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MPFRM02CarlNumos"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents RdLarge As System.Windows.Forms.RadioButton
    Friend WithEvents RdMedium As System.Windows.Forms.RadioButton
    Friend WithEvents RdSmall As System.Windows.Forms.RadioButton
    Friend WithEvents RdThickcrust As System.Windows.Forms.RadioButton
    Friend WithEvents RdThincrust As System.Windows.Forms.RadioButton
    Friend WithEvents RdFruitjuice As System.Windows.Forms.RadioButton
    Friend WithEvents RdSoftdrinks As System.Windows.Forms.RadioButton
    Friend WithEvents Rddine As System.Windows.Forms.RadioButton
    Friend WithEvents Rdtake As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents ChkTomato As System.Windows.Forms.CheckBox
    Friend WithEvents ChkGreenpeppers As System.Windows.Forms.CheckBox
    Friend WithEvents ChkOnion As System.Windows.Forms.CheckBox
    Friend WithEvents Chkblack As System.Windows.Forms.CheckBox
    Friend WithEvents ChkMush As System.Windows.Forms.CheckBox
    Friend WithEvents ChkExtracheese As System.Windows.Forms.CheckBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents RdCofchoc As System.Windows.Forms.RadioButton
End Class
