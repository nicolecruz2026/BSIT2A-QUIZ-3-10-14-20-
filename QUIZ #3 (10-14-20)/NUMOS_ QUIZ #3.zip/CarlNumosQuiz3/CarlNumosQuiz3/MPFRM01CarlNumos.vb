﻿Public Class MPFRM01CarlNumos




    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedItem = "10011ABC" Then
            TextBox1.Text = "MAXSPAUN GREY"
            ComboBox2.Text = "100A"
        End If
        If ComboBox1.SelectedItem = "10012DEF" Then
            TextBox1.Text = "Carl Numos"
            ComboBox2.Text = "100B"
        End If
        If ComboBox1.SelectedItem = "10013GHI" Then
            TextBox1.Text = "Leslie Yasay"
            ComboBox2.Text = "100C"
        End If

    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim bp, sss, wt, np, tr, cb As Double
        If ComboBox1.SelectedItem = "10011ABC" Then
            cb = 500
        End If
        If ComboBox1.SelectedItem = "10012DEF" Then
            cb = 400
        End If
        If ComboBox1.SelectedItem = "10013GHI" Then
            cb = 300
        End If
        If RadioButton1.Checked Then
            tr = 0.1
        End If
        If RadioButton2.Checked Or RadioButton3.Checked Then
            tr = 0.05
        End If
        If bp >= 10000 Then
            sss = 0.07
        End If
        If bp >= 5000 Then
            sss = 0.05
        End If
        If bp >= 1000 Then
            sss = 0.03
        End If
        If bp <= 999 Then
            sss = 0.01
        End If
        bp = NumericUpDown1.Value * cb
        sss = bp * sss
        wt = bp * tr
        np = bp - (sss + wt)
        TextBox2.Text = bp
        TextBox3.Text = sss
        TextBox4.Text = wt
        TextBox5.Text = np

    End Sub
   
    
    
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        NumericUpDown1.Value = False
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
    End Sub


End Class
