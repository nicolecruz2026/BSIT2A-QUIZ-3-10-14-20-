﻿Public Class Form1


    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedItem.ToString = "1000" Then
            TextBox1.Text = "Jennry Garduque"
        ElseIf ComboBox1.SelectedItem.ToString = "1001" Then
            TextBox1.Text = "Stephen Curry"
        ElseIf ComboBox1.SelectedItem.ToString = "1002" Then
            TextBox1.Text = "Wright James"
        ElseIf ComboBox1.SelectedItem.ToString = "1003" Then
            TextBox1.Text = "Fisherman Jones"
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim sss, val As Integer
        Dim CivilS As Double
        Dim Tax As Double

        If ComboBox2.Text = "A" Then
            TextBox2.Text = (500 * NumericUpDown1.Value)
        ElseIf ComboBox2.Text = "B" Then
            TextBox2.Text = (400 * NumericUpDown1.Value)
        ElseIf ComboBox2.Text = "C" Then
            TextBox2.Text = (300 * NumericUpDown1.Value)
        Else
        End If


        val = TextBox2.Text


        If val >= 10000 Then
            sss = (val * 0.07)
            TextBox3.Text = sss
        End If
        If (val >= 5000) And (val <= 9000) Then
            sss = (val * 0.05)
            TextBox3.Text = sss
        End If
        If (val >= 1000) And (val <= 4999) Then
            sss = (val * 0.03)
            TextBox3.Text = sss
        End If
        If val <= 1000 Then
            sss = (val * 0.01)
            TextBox3.Text = sss
        End If


        If RadioButton1.Checked = True Then
            CivilS = 0.1
        End If
        If RadioButton2.Checked = True Then
            CivilS = 0.05
        End If
        If RadioButton3.Checked = True Then
            CivilS = 0.05
        End If


        Tax = val * CivilS
        TextBox4.Text = tax
        TextBox5.Text = val - tax - sss
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
        NumericUpDown1.Value = 0
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class
